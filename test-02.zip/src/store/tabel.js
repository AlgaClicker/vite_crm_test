import { instance } from '@/modules/webclient.js'
import { isProxy, toRaw, ref } from 'vue';

const state = {
    mesagges: [],

};
const getters = {
  
};

const actions = {
  
};

const mutations = {
 
};

export default {
  state,
  getters,
  actions,
  mutations
};