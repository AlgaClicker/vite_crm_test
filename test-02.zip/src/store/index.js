import Vuex from 'vuex';
import createPersistedState from "vuex-persistedstate";
import auth from '../modules/auth.js';
import websocket from './websocket.js';
import objects from './objects.js'
import accountCompany from './accountCompany.js';
import chat from './chat.js';

// Load Vuex

// Create store
export default new Vuex.Store({
  modules: {
    auth,
    websocket,
    chat,
    accountCompany,
    objects
  },
  plugins: [createPersistedState()]
});