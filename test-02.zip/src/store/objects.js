import { instance } from '@/modules/webclient.js'

const state = {
    object: null,
    company_id: null,
    account_id: null
};
const getters = {

};

const actions = {
    async getListObjects() {

    }
};

const mutations = {

};
export default {
  state,
  getters,
  actions,
  mutations
};