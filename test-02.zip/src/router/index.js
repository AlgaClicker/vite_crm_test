import { createRouter, createWebHashHistory  } from 'vue-router'
import IndexPage from '@/pages/IndexPage.vue'
import LoginPage from '@/pages/LoginPage.vue'
import CmsLayout from '@/pages/CmsLayout.vue'
import ObjectPage from '@/pages/ObjectPage.vue'
import ChatPage from '@/pages/ChatPage.vue'
import store from "@/store";

const routes = [
    {
      path: '/',
      name: 'Home',
      component: IndexPage,
      meta: { 
        requiresAuth: false
      },
    },
    {
        path: '/login',
        name: 'Login',
        component: LoginPage,
        meta: { 
          requiresAuth: false
        },
    },
    {
        path: '/cms',
        name: 'CMS',
        component: CmsLayout,
        meta: { 
          requiresAuth: true
        },
        children: [
          {
            path: "object",
            name: "cms_object",
            component: ObjectPage
          },
          {
            path: "chat",
            name: "cms_chat",
            component: ChatPage
          },

        ]
    },
  

]

const router = new createRouter({
    mode: 'history',
    history: createWebHashHistory(),
    routes
})


router.beforeEach(async (to, from, next) => {
    console.log("router Next()")

    if (to.name == 'Login' && store.getters.isAuthenticated  && to.meta.requiresAuth) {
      return next('/cms')
    } 
    

    if (!to.meta.requiresAuth) {
        next()
        return
    } 
    await store.dispatch('getMe')

    if (store.getters.isAuthenticated && to.meta.requiresAuth) {
      next()
    } else {
      store.dispatch('logout')
        next('/login')
    }
})

export default router  