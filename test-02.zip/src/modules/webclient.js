import axios from 'axios';
import store from '@/store';
import router from '@/router'
export const instance = axios.create({
    baseURL: import.meta.env.VITE_APP_API,
    withCredentials: false,
    headers: {
      Accept: 'application/json',
      'Content-Type': 'application/json',
    },
});

instance.defaults.timeout = 8500;
instance.defaults.headers.post['Content-Type'] ='application/json;charset=utf-8';
instance.defaults.headers.post['Access-Control-Allow-Origin'] = '*';
 

instance.interceptors.request.use( config  => {

    if (store.getters.isAuthenticated) {
      console.log("set Token")
        const token = store.getters.getToken;
        config.headers.Authorization = token ? `Bearer ${token}` : "";
    
    }
    return config;
});


instance.interceptors.response.use(undefined, function (error) {
    console.log('error webclient')
    console.log(error)
    if (error) {
      const originalRequest = error.config;
      if (error.response.status === 400) {
        store.dispatch('logout')
        return router.push('/login')
      }
      if (error.response.status === 401) {
            console.log('error 401')
          originalRequest._retry = true;
          store.dispatch('logout')
          return router.push('/login')
      }
    }
  })

instance.interceptors.response.use( response => {
    return response;
})




export default instance