<template>
    list Object 

</template>

<script>
import { mapGetters, mapState, mapActions  } from 'vuex'

export default {
    data ()  {
        return {

        }
    },
    mounted() {

    },
    computed() {

    },
    methods: {
        ...mapActions({
            login: 'LogIn',
            ws_init: 'ws_init',
            getMe: 'getMe',
            
        }),
    }
    
}
</script>