<template>
    <div class="row">
        Бухгалтерия
    </div>
    <router-view></router-view>
</template>