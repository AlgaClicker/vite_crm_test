<template>
        <div class="row">
        Кадры
    </div>
    <router-view></router-view>
</template>