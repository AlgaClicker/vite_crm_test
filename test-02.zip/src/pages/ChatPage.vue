<script setup>
import ChatModule from '../components/ChatModule.vue';
</script>

<template>
    <ChatModule></ChatModule>
</template>