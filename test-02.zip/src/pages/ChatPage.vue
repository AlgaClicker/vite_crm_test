<script setup>
import ChatModule from '../components/ChatModule.vue';
</script>

<template>
    Chat page
    <br>
    <ChatModule></ChatModule>
</template>