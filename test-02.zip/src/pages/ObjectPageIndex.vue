<template>
    <div>
        object page
    </div>
</template>