<template>

    

    <div class="row h-100" >
        <div class="col-2">
            <ul class="nav flex-column">
                <li class="nav-item">
                    <router-link  class="nav-link" active-class="active" to="/cms/object">Объекты</router-link> 
                </li>
                <li class="nav-item">
                    <router-link  class="nav-link" active-class="active" to="/cms/chat">Чат</router-link> 
                </li>
            </ul>
        </div>
        <div class="col-7">
            <router-view></router-view>
        </div>
        <div class="col-3" style="background-color: azure;">

           Accounts: 
           <div class="accordion accordion-flush" id="accordionFlushExample" v-if="accountsOnline_ws">
            <div class="accordion-item" v-for="(onlineAcc, idx) in accountsOnline_ws">
                <h2 class="accordion-header" v-if="onlineAcc">
                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" :data-bs-target="'#flush-collapseOne'+idx" aria-expanded="false" aria-controls="flush-collapseOne">
                    {{ onlineAcc.username }}
                </button>
                </h2>
                <div :id="'flush-collapseOne'+idx" class="accordion-collapse collapse" data-bs-parent="#accordionFlushExample">
                    <div class="accordion-body">
	                    {{ onlineAcc}}
	                </div>
                </div>
            </div>
           </div>

        </div>
    
    </div>

</template>

<script>
import { mapGetters, mapState, mapActions  } from 'vuex'
import store from '../store'
export default {
    data() {
        return {
        username : "",
        }
    },
    computed: {
        ...mapGetters({
        isAuth: 'isAuthenticated',
        account: 'StateAccount',
        accountsOnline_ws: 'accountsOnline_ws'
        }),
         company: async () => {
            console.log("computed:company"+this.account)
        }
    },
    mounted() {
        console.log('mounted')
        this.ws_init
        this.username = this.getMe
        console.log(this.account.company)
        store.dispatch('joinChatCompnay_ws',this.account.company.id)
        //joinChatCompnay_ws
        //store.dispatch('userConnect_ws',this.account)
    },
    methods: {
        ...mapActions({
            login: 'LogIn',
            ws_init: 'ws_init',
            getMe: 'getMe',
            
        }),
        submit : async function(e) {
            console.log("subm"),
            await this.login({
                username: this.username,
                password: this.password
            })
        }
    }
}
</script>