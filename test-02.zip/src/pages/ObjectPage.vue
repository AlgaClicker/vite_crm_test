<template>
    Object Page
</template>