import { createApp } from 'vue'
import App from './App.vue'


import router from './router';
import store from './store';
import axios from 'axios';
import io from 'socket.io-client'
import * as Popper from '@popperjs/core'
import * as bootstrap from 'bootstrap'
import 'bootstrap/dist/css/bootstrap.css'
import './style.css'
window.io = io;
window.Popper = Popper

const app = createApp(App)
app.use(store)
app.use(router)
app.mount('#app')