<script setup>

</script>

<template>
  <div class="row menu">
    <div class="col">
      <nav class="navbar navbar-light bg-light navbar-expand-sm justify-content-between">
      <ul class="navbar-nav mr-auto">
        <li class="nav-item">
          <router-link  class="nav-link" active-class="active" to="/">Index</router-link>
        </li>
        <li class="nav-item" v-show="!isAuth">
          <router-link  class="nav-link" active-class="active" to="/login">Login</router-link> 
        </li>
        <li class="nav-item" v-show="isAuth">
          <router-link  class="nav-link" active-class="active" to="/cms">CMS</router-link> 
        </li>
        <li class="nav-item" v-show="isAuth">
          <a href="#" class="nav-link" v-on:click="logout">LogOut</a> 
        </li>

        <li class="nav-item">
          <div class="nav-link disabled">
            IsAuth: {{ isAuth }}
          </div>
         
        </li>
      </ul>
      
      <form class="form-inline my-2 my-lg-0 " v-if="company && account">
        <button class="btn btn-outline-success my-2 mx-3 my-sm-0">{{ company.name }}</button>  
      <button class="btn btn-info my-2 my-sm-0">{{ account.username }}</button>
      
      </form>
    </nav>

    </div>
  </div>
  <div class="row layout">
    <div class="col h-100"> 
      <router-view></router-view>
    </div>

  </div>
  <div class="fixed-bottom footer" >
      foot
    </div>
</template>

<script>
import { mapGetters, mapActions } from 'vuex'
export default {
  computed: {
    ...mapGetters({
        isAuth: 'isAuthenticated',
        account: 'StateAccount',
        company: 'getCompany'
    })
  },
  mounted(){
    console.log("APP mounted",this.company)
  },
  methods: {
    async logout (){
        this.$store.dispatch('logout')
        this.$router.push('/')
    }
  }
}
</script>
<style >
html,boby {
  height: 100%;
  min-height: 100%;
  width: 100%;
  min-width: 100%;
  display: flex;
}

.footer {
  background-color: brown;
  width: 100%;
  color: aliceblue;
  text-align: center;
}


.layout {
  padding-top: 10px;
  min-height: 100hv !important; 
  height: 100%;
  margin-bottom: 30px;
}
.menu {
  min-height: 50px !important;
  height: 50px;
}
</style>
